package de.berdsen.telekomsport_unofficial.model;

/**
 * Created by Berdsen on 19.10.2017.
 */

public class TestClass {
}
