package de.berdsen.telekomsport_unofficial.services.model;

import lombok.Data;

/**
 * Created by Berdsen on 08.10.2017.
 */

@Data
public class LoginUserData {
    private String username;
    private String password;
}
