package de.berdsen.telekomsport_unofficial.model;

/**
 * Created by Berdsen on 29.12.2017.
 */

public enum SpecifiedVideoType {
    Summary,
    Playback,
    Magazine,
    Unknown
}
