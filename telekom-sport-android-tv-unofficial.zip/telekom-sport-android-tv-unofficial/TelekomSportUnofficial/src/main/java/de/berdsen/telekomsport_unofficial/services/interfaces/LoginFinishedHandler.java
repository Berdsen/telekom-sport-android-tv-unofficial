package de.berdsen.telekomsport_unofficial.services.interfaces;

/**
 * Created by Berdsen on 06.10.2017.
 */

public interface LoginFinishedHandler {
    void loginFailed();

    void loginSucceeded();
}
