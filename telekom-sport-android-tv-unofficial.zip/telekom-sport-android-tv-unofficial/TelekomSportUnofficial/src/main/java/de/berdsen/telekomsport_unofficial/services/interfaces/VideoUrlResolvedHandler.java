package de.berdsen.telekomsport_unofficial.services.interfaces;

/**
 * Created by Berdsen on 24.10.2017.
 */

public interface VideoUrlResolvedHandler {
    void resolvedVideoUrl(String urlString, String errorMessage);
}
