package de.berdsen.telekomsport_unofficial.model;

public class BoxScoreContent extends BaseContent {
}
